<?php
// Konfigurasi koneksi ke API AiYO Bills Invoice (DBI)
// Nilai xxx harus diganti sesuai kredensial yang didapat dari dashboard DBI

$host        = "https://api-bills-invoice.aiyo.id";
$username    = "xxx"; // username DEV dari dashboard DBI
$password    = "xxx"; // password DEV dari dashboard DBI
$billMasterId = "xxx"; // lihat di dashboard DBI
$api_key     = "xxx";
$api_secret  = "xxx";
?>

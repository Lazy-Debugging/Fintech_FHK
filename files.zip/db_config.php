<?php
// Konfigurasi koneksi database MySQL
// File ini tidak ada di slide, tapi di-include oleh respon.php
// Sesuaikan nilai di bawah dengan database Anda

$db_host = "localhost";
$db_user = "xxx";
$db_pass = "xxx";
$db_name = "xxx";

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
